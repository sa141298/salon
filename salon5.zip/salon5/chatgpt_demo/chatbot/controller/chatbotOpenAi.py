import re
import json
from chatbot.controller.crearEventoCalendarGoogle import calendar


class chatBotOpenAi:

    @staticmethod
    def delete_event(response):
        json_pattern = r"(\{.*\})"
        match = re.search(json_pattern, response)
        if match:
            json_str = match.group(0)
            json_data = json.loads(json_str)
            estado = calendar.delete_event_chatbot([json_data["correo"]],
                                                   json_data["servicios"])
            return estado
        else:
            print("No se encontró un JSON válido en la cadena.")
            return False

    @staticmethod
    def analyze_response(response=None):
        if "validaCita" in response:
            if chatBotOpenAi.check_disponibilidad(response):
                return "¡Perfecto! ¡Tu cita ha sido agendada con éxito!"
            else:
                return "Lo siento, pero no pude agendar tu cita. Por favor, inténtalo de nuevo."
        elif "cambioCita" in response:
            if chatBotOpenAi.update_event(response):
                return "¡Perfecto! ¡Tu cita ha sido actualizada con éxito!"
            else:
                return "Lo siento, pero no pude actualizar tu cita. Por favor, inténtalo de nuevo."
        elif "eliminaCita" in response:
            if chatBotOpenAi.delete_event(response):
                return "¡Tu cita ha sido eliminada con éxito!"
            else:
                return "Lo siento, pero no pude eliminar tu cita. Por favor, inténtalo de nuevo."
        return response

    @staticmethod
    def check_disponibilidad(response):
        json_pattern = r"(\{.*\})"
        match = re.search(json_pattern, response)
        if match:
            json_str = match.group(0)
            json_data = json.loads(json_str)
            summary = ("Cita de " + json_data["nombre"] +
                       " para el servicio de " + json_data["servicios"] +
                       " en NY BEAUTY SALON")
            start_time = json_data["fecha"] + "T" + json_data[
                "hora_inicio"] + ":00-04:00"
            end_time = json_data["fecha"] + "T" + json_data[
                "hora_fin"] + ":00-04:00"
            timezone = "America/Santo_Domingo"
            calendar.create_event(summary, start_time, end_time, timezone,
                                  [json_data["correo"]])
            return True
        else:
            print("No se encontró un JSON válido en la cadena.")
            return False

    @staticmethod
    def update_event(response):
        json_pattern = r"(\{.*\})"
        match = re.search(json_pattern, response)
        if match:
            json_str = match.group(0)
            json_data = json.loads(json_str)
            summary = ("Cita de " + json_data["nombre"] +
                       " para el servicio de " + json_data["servicios"] +
                       " en NY BEAUTY SALON")
            start_time = json_data["fecha"] + "T" + json_data[
                "hora_inicio"] + ":00-04:00"
            end_time = json_data["fecha"] + "T" + json_data[
                "hora_fin"] + ":00-04:00"
            estado = calendar.update_event_chatbot(summary, start_time,
                                                   end_time,
                                                   [json_data["correo"]],
                                                   json_data["servicios"])
            return estado
        else:
            print("No se encontró un JSON válido en la cadena.")
            return False


chatBotSalon = chatBotOpenAi()
