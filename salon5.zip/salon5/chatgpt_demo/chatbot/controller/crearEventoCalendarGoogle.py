import os.path
import datetime as dt

from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

SCOPES = ["https://www.googleapis.com/auth/calendar"]
IDCALENDARIO = "a5f685b17d01b721fa36f76261a5254aef4ad4e523db1f7a5ca61e351c7fd474@group.calendar.google.com"


class GoogleCalendarManager:

    def __init__(self):
        self.service = self._authenticate()

    def _authenticate(self):
        creds = None

        if os.path.exists("token.json"):
            creds = Credentials.from_authorized_user_file("token.json", SCOPES)

        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                flow = InstalledAppFlow.from_client_secrets_file(
                    "cred.json", SCOPES)
                creds = flow.run_local_server(port=0)

            # Save the credentials for the next run
            with open("token.json", "w") as token:
                token.write(creds.to_json())

        return build("calendar", "v3", credentials=creds)

    def create_event(self,
                     summary,
                     start_time,
                     end_time,
                     timezone,
                     attendees=None):
        event = {
            "summary": summary,
            "start": {
                "dateTime": start_time,
                "timeZone": timezone,
            },
            "end": {
                "dateTime": end_time,
                "timeZone": timezone,
            },
            "reminders": {
                "useDefault":
                False,
                "overrides": [
                    {
                        "method": "email",
                        "minutes": 24 * 60
                    },
                    {
                        "method": "popup",
                        "minutes": 10
                    },
                ],
            },
        }

        if attendees:
            event["attendees"] = [{"email": email} for email in attendees]

        try:
            event = self.service.events().insert(calendarId=IDCALENDARIO,
                                                 body=event).execute()
            print(f"Event created: {event.get('htmlLink')}")
        except HttpError as error:
            print(f"An error has occurred: {error}")

    def list_upcoming_events_chatbot(self,
                                     max_results=1000,
                                     email=None,
                                     servicio=None):
        now = dt.datetime.now(dt.timezone.utc).isoformat()
        tomorrow = (dt.datetime.now() + dt.timedelta(days=10)).replace(
            hour=23, minute=59, second=0, microsecond=0).isoformat() + "Z"

        events_result = self.service.events().list(
            calendarId=IDCALENDARIO,
            timeMin=now,
            timeMax=tomorrow,
            maxResults=max_results,
            singleEvents=True,
            orderBy="startTime",
        ).execute()
        events = events_result.get("items", [])

        if not events:
            return events
        else:
            filtered_events = [
                event for event in events
                if any(attendees["email"] == email[0]
                       for attendees in event.get("attendees", []))
                and servicio in event.get("summary", "")
            ]

        return filtered_events

    def update_event_chatbot(self,
                             summary=None,
                             start_time=None,
                             end_time=None,
                             email=None,
                             servicio=None):
        evento = self.list_upcoming_events_chatbot(email=email,
                                                   servicio=servicio)
        if len(evento) > 0:
            event_id = evento[0]["id"]
        else:
            return False

        event = self.service.events().get(calendarId=IDCALENDARIO,
                                          eventId=event_id).execute()

        if summary:
            event["summary"] = summary

        if start_time:
            start_time_dt = dt.datetime.fromisoformat(start_time)
            event["start"]["dateTime"] = start_time_dt.strftime(
                "%Y-%m-%dT%H:%M:%S")

        if end_time:
            end_time_dt = dt.datetime.fromisoformat(end_time)
            event["end"]["dateTime"] = end_time_dt.strftime(
                "%Y-%m-%dT%H:%M:%S")

        try:
            event = self.service.events().update(calendarId=IDCALENDARIO,
                                                 eventId=event_id,
                                                 body=event).execute()
            return True
        except HttpError as error:
            print(error)
            return False

    def delete_event_chatbot(self, email=None, servicio=None):
        evento = self.list_upcoming_events_chatbot(email=email,
                                                   servicio=servicio)
        if len(evento) > 0:
            event_id = evento[0]["id"]
        else:
            return False

        try:
            self.service.events().delete(calendarId=IDCALENDARIO,
                                         eventId=event_id).execute()
            return True
        except HttpError as error:
            print(error)
            return False


calendar = GoogleCalendarManager()
